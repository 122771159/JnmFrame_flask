from flask import jsonify, request, g

from Exception.jwt.JwtExpiredException import JWTExpiredException
from app import creatApp
from common.redis_client import get_redis_client
from exts import db
from flask_cors import CORS
from flask_migrate import Migrate

from utils.jwtUtils import get_payload

app = creatApp()

except_jwt = ['login', 'register', 'logout']


@app.before_request
def jwt_authentication():
    g.data = request.get_json(silent=True)
    if request.method == 'OPTIONS':
        return
    for i in except_jwt:
        if i in request.path:
            return
    token = request.headers.get('Authorization')
    client = get_redis_client()
    if not client.get(token):
        raise JWTExpiredException()
    g.user_info = get_payload(token)



CORS(app, supports_credentials=True)
migrate = Migrate(app, db)


@app.route('/')
# @login_required
def hello_world():  # put application's code here
    routes = []
    for rule in app.url_map.iter_rules():
        routes.append({
            "endpoint": rule.endpoint,
            "methods": list(rule.methods),
            "url": rule.rule
        })
    return jsonify(routes)


if __name__ == '__main__':
    app.run(debug=True)
