import json
import time

from flask import Blueprint, request, g
from marshmallow import ValidationError

from common.redis_client import get_redis_client
from common.schemas import UserSchema, format_validation_error
from common.R import fail, success
from model import User, Url, UrlSerializer, RoleSerializer, PermSerializer, UserSerializer, Role
from utils.jwtUtils import create_token
from utils.urlUtils import transform_data

RoleBp = Blueprint('RoleBp', __name__, url_prefix='/role')


@RoleBp.route('/roles', methods=['GET', 'POST'])
def get_roles():
    roles = Role.query.all()
    serializer = RoleSerializer(many=True)
    roles = serializer.dump(roles)
    return success(roles)
