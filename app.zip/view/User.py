import json
import time

from flask import Blueprint, request, g
from marshmallow import ValidationError

from common.redis_client import get_redis_client
from common.schemas import UserSchema, format_validation_error
from common.R import fail, success
from model import User, Url, UrlSerializer, RoleSerializer, PermSerializer, UserSerializer
from utils.jwtUtils import create_token
from utils.urlUtils import transform_data

UserBp = Blueprint('UserBp', __name__, url_prefix='/user')


@UserBp.route('/login', methods=['POST'])
def login():
    json_data = request.get_json()
    if not json_data:
        return fail("没有提供输入数据")
    user_schema = UserSchema()
    try:
        data = user_schema.load(json_data)
        user = User.query.filter_by(username=data['username']).first()

        if not user:
            return fail("没有此用户")
        if not user.check_password(data['password']):
            return fail("密码错误")
        if len(user.roles) > 0:
            role = user.roles[0]
            perms = role.perms
            role = RoleSerializer().dump(role)
            perms = PermSerializer(many=True).dump(perms)

        else:
            role = []
            perms = []
        EXPIRES = 60 * 60 * 24  # 24小时（以秒为单位）
        if 'rememberMe' in json_data:
            EXPIRES = 60 * 60 * 24 * 365
        user_exp_time = (time.time() + EXPIRES)
        user_exp_time = int(user_exp_time)
        user = {
            'id': user.id,
            'username': user.username,
            'name': user.name,
            'avatar': user.avatar,
            'exp': user_exp_time,
            # 'exp': time.time() + 10,
            'role': role,
        }
        jwt = create_token(user)
        data = json.dumps({
            "id": user['id'],
            "exp": user_exp_time
        })
        redis_client = get_redis_client()
        redis_client.set(jwt, data, EXPIRES)
        redis_client.set(f"role{user['id']}", json.dumps(data))
        res = {
            'token': jwt,
            'user': user,
            'exp': user_exp_time,
            'urls': [],
            'perms': perms,
        }
        return success(res)
    except ValidationError as err:
        return fail(format_validation_error(err))


@UserBp.route('/urls', methods=['GET'])
def get_urls():
    user_id = g.user_info['id']
    if user_id == 1:
        urls = Url.query.all()
    else:
        user = User.query.filter_by(id=user_id).first()
        role = user.roles[0]
        urls = role.urls
    urls_schema = UrlSerializer(many=True)
    urls = urls_schema.dump(urls)

    return success(transform_data(urls))


@UserBp.route('/perms', methods=['GET'])
def get_perms():
    user_id = g.user_info['id']
    user = User.query.filter_by(id=user_id).first()
    if len(user.roles) <= 0:
        return success([])
    role = user.roles[0]
    perms = role.perms
    perms = PermSerializer(many=True).dump(perms)
    return success(perms)


@UserBp.route('/users', methods=['GET'])
def get_users():
    users = User.query.filter(User.id != 1).all()
    serializer = UserSerializer(many=True)
    users = serializer.dump(users)
    return success(users)


@UserBp.route('/get_user', methods=['POST'])
def get_user():
    id = g.data['id']
    user = User.query.filter_by(id=id).first()
    if not user:
        return fail("不存在此用户")
    role = []
    if len(user.roles) > 0:
        role = [user.roles[0].id]
    user = UserSerializer().dump(user)
    user['roles'] = role
    return success(user)
@UserBp.route('/change_user', methods=['POST'])
def change_user():
    id = g.data['id']
    pass